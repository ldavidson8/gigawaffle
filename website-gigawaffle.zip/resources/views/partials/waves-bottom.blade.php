<picture>
    <source media="(max-width: 428px)" srcset="{{ asset('img/waves/wavesMobileBottom.png') }}" />
    <img src="{{ asset('img/waves/wavesDesktopBottom.png') }}" alt="" style="max-width: 100%; vertical-align: bottom; position: relative; top: 1px;" />
</picture>
